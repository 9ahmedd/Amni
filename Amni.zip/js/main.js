let more = document.getElementById("more");
let lgs1 = document.getElementById("lgs1");
let lgs2 = document.getElementById("lgs2");
let lgs3 = document.getElementById("lgs3");
let lgs4 = document.getElementById("lgs4");
let lgs5 = document.getElementById("lgs5");
let lgs6 = document.getElementById("lgs6");
let lgs7 = document.getElementById("lgs7");
let lgs8 = document.getElementById("lgs8");
let lgs9 = document.getElementById("lgs9");
let lgs10 = document.getElementById("lgs10");
let lgs11 = document.getElementById("lgs11");
let ull = document.getElementById("ull");


more.addEventListener("click", () => {
    more.style.cssText = "display:none";
    ull.style.cssText = "height:auto";
    lgs1.style.cssText = "display:block";
    lgs2.style.cssText = "display:block";
    lgs3.style.cssText = "display:block";
    lgs4.style.cssText = "display:block";
    lgs5.style.cssText = "display:block";
    lgs6.style.cssText = "display:block";
    lgs7.style.cssText = "display:block";
    lgs8.style.cssText = "display:block";
    lgs9.style.cssText = "display:block";
    lgs10.style.cssText = "display:block";
    lgs11.style.cssText = "display:block";
})